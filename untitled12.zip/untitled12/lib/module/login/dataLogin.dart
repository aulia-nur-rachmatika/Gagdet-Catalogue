class DataLogin{
  final int id;
  final String nama;
  final String username;
  final String password;
  

  DataLogin(
      {required this.id,
        required this.nama,
        required this.username,
        required this.password
      });
}

var datadata=
[
DataLogin(id:1 , nama: 'Aulia', username:'auliatika' , password: "12345"),
DataLogin(id:2 , nama: 'Nur', username:'nur_aulia' , password: "123"),
DataLogin(id:3 , nama: 'Rachma', username:'rachma_tika' , password: "tika123"),


];